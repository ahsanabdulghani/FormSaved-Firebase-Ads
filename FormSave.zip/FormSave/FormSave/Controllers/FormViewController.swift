//
//  FormViewController.swift
//  FormSave
//
//  Created by MacBook Pro on 05/12/2023.
//

import UIKit
import Firebase
import FirebaseAnalytics
import FirebaseDatabase
import GoogleMobileAds
import FirebaseRemoteConfig

class FormViewController: UIViewController, GADBannerViewDelegate {

    //MARK: -  @IBOutlet
    
    @IBOutlet weak var logoIcon: UIImageView!
    @IBOutlet var baseView: UIView!
    @IBOutlet weak var bannerView: GADBannerView!
    @IBOutlet weak var inputTextField: UITextField!

    var buttonOneCount = 0
    var buttonSecondCount = 0
    var buttonThreeCount = 0
    
    private let remoteConfig = RemoteConfig.remoteConfig()


    override func viewDidLoad() {
        super.viewDidLoad()

        bannerAds()
        fetchValue()
    }

    func bannerAds() {
        bannerView.adUnitID = "ca-app-pub-3940256099942544/2934735716"
        bannerView.rootViewController = self
        bannerView.delegate = self
        bannerView.load(GADRequest())
    }
    
    //MARK: -  Firebase Remote Congiguration
    func fetchValue() {
        let settings = RemoteConfigSettings()
        settings.minimumFetchInterval = 0
        remoteConfig.configSettings = settings
        
        self.remoteConfig.fetch(withExpirationDuration: 0) { status, error in
            if status == .success, error == nil {
                self.remoteConfig.activate(completion: { _, _ in
                    let remoteConfigDemo = self.remoteConfig.configValue(forKey: "RemoteConfigureDemo").jsonValue as? [String: Any] ?? [:]
                    
                    let bannerValue = remoteConfigDemo["banner"] as? [String: Any]
                    let bannerStatus = bannerValue?["value"] as? Int ?? 0
                    print("banner Value Fetch: \(bannerStatus)")
                    DispatchQueue.main.async {
                        self.UpdateAdsViaFirebase(status: bannerStatus)
                    }
                    
                    let iconValue = remoteConfigDemo["logoicon"] as? [String: Any]
                    let iconStatus = iconValue?["Value"] as? Int ?? 0
                    print("icon Value Fetch: \(iconStatus)")
                    DispatchQueue.main.async {
                        self.iconUpdateAdsViaFirebase(status: iconStatus)
                    }
                    
                    let viewValue = remoteConfigDemo["viewcolor"] as? [String: Any]
                    let viewStatus = viewValue?["Value"] as? Int ?? 0
                    print("view Value Fetch: \(viewStatus)")
                    DispatchQueue.main.async {
                        self.viewUpdateAdsViaFirebase(status: viewStatus)
                    }
                    
                })
            } else {
                print("Something went wrong")
            }
        }
    }
    
    func UpdateAdsViaFirebase(status: Int) {
        if status == 1 {
            bannerView.isHidden = false
        } else {
            bannerView.isHidden = true
        }
    }
    
    
    func iconUpdateAdsViaFirebase(status: Int) {
        if status == 1 {
            logoIcon.image  = UIImage(named: "1")
        } else {
            logoIcon.image  = UIImage(named: "0")
        }
    }
    
    func viewUpdateAdsViaFirebase(status: Int) {
        if status == 1 {
            baseView.backgroundColor = .red
        } else {
            baseView.backgroundColor = .blue
        }
    }
    
    
    
    
    @IBAction func submitButton(_ sender: Any) {
        saveDataToFirebaseDatabase()
        Analytics.logEvent("submitButton", parameters: nil)
    }

    @IBAction func buttonOne(_ sender: Any) {
        buttonOneCount += 1
        saveButtonClickCountToFirebase(buttonCount: buttonOneCount, buttonName: "buttonOneCount")
    }

    @IBAction func buttonSecond(_ sender: Any) {
        buttonSecondCount += 1
        saveButtonClickCountToFirebase(buttonCount: buttonSecondCount, buttonName: "buttonSecondCount")
    }

    @IBAction func buttonThree(_ sender: Any) {
        buttonThreeCount += 1
        saveButtonClickCountToFirebase(buttonCount: buttonThreeCount, buttonName: "buttonThreeCount")
    }

    func saveDataToFirebaseDatabase() {
        guard let userInput = inputTextField.text, !userInput.isEmpty else {
            return
        }

        let ref = Database.database().reference().child("UserInputs")
        let newChildRef = ref.childByAutoId()

        newChildRef.setValue(["input": userInput]) { (error, _) in
            if let error = error {
                print("Error adding data to Firebase Database: \(error.localizedDescription)")
            } else {
                print("Data added successfully to Firebase Database")
            }
        }
    }

    func saveButtonClickCountToFirebase(buttonCount: Int, buttonName: String) {
        let ref = Database.database().reference().child("ButtonClickCounts").child(buttonName)
        ref.setValue(buttonCount) { (error, _) in
            if let error = error {
                print("Error adding count to Firebase Database: \(error.localizedDescription)")
            } else {
                print("Count added successfully to Firebase Database")
            }
        }
    }
}
   
